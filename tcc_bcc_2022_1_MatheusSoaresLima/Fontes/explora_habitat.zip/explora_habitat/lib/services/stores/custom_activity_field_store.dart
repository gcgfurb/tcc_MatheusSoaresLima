import 'package:mobx/mobx.dart';

part 'custom_activity_field_store.g.dart';

class CustomActivityFieldStore = _CustomActivityFieldStore with _$CustomActivityFieldStore;

abstract class _CustomActivityFieldStore with Store {



}