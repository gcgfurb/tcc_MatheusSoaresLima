import 'package:flutter/material.dart';

const green = Colors.green;
const darkGreen = Color(0xFF06170e);
const darkerGreen = Color(0xFF001004);
const seaGreen = Color(0xFF2E8B57);