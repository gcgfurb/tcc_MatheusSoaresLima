package br.com.furb.explora_habitat

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
